import recursive.agent.prompts.story_writing_wo_search_nl_version_english
import recursive.agent.prompts.report
import recursive.agent.prompts.search_agent












