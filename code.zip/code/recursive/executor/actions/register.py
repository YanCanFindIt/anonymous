

from recursive.utils.register import Register

tool_register = Register('tool_register')
executor_register = Register('executor_register')
