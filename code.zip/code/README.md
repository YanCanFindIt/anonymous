
WriteHERE is an open-source framework that revolutionizes long-form writing through human-like adaptive planning. Unlike traditional AI writing tools that follow rigid workflows, WriteHERE dynamically decomposes writing tasks and integrates three fundamental capabilities:

1. **Recursive Planning**: Breaks down complex writing tasks into manageable subtasks
2. **Heterogeneous Integration**: Seamlessly combines retrieval, reasoning, and composition
3. **Dynamic Adaptation**: Adjusts the writing process in real-time based on context

Our evaluations show that this approach consistently outperforms state-of-the-art methods in both fiction writing and technical report generation.

# 🔍 Overview

Unlike traditional approaches that rely on predetermined workflows and rigid thinking patterns, this framework:

1. **Eliminates workflow restrictions** through a planning mechanism that interleaves recursive task decomposition and execution
2. **Facilitates heterogeneous task decomposition** by integrating different task types
3. **Adapts dynamically** during the writing process, similar to human writing behavior

Our evaluations on both fiction writing and technical report generation demonstrate that this method consistently outperforms state-of-the-art approaches across all evaluation metrics.

## 🚀 Getting Started

### Prerequisites

- Python 3.6+
- Node.js 14+ (for the frontend)
- API keys for:
  - OpenAI (GPT models)
  - Anthropic (Claude models)
  - SerpAPI (for search functionality in report generation)

### Quickstart

1. **Setup the environment**:
```bash
python -m venv venv
source venv/bin/activate
pip install -v -e .

# Create api_key.env file based on example
cp recursive/api_key.env.example recursive/api_key.env
# Edit the file to add your keys
nano recursive/api_key.env
```


2. **Run the engine directly**:
```bash
cd recursive
python engine.py --filename <input_file> --output-filename <output_file> --done-flag-file <done_file> --model <model_name> --mode <story|report>
```

Example for generating a story:
```bash
python engine.py --filename ../test_data/meta_fiction.jsonl --output-filename ./project/story/output.jsonl --done-flag-file ./project/story/done.txt --model gpt-4o --mode story
```

Example for generating a report:
```bash
python engine.py --filename ../test_data/qa_test.jsonl --output-filename ./project/qa/result.jsonl --done-flag-file ./project/qa/done.txt --model claude-3-sonnet --mode report
```
